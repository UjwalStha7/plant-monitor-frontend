# Plant Monitoring Backend

Backend API for ESP32 Plant Monitoring System

## Deployment
This backend is deployed on Render.